﻿
using Shopping_Cart.Models;
using System;
using System.Web.Mvc;

namespace Shopping_Cart.Models
{
    public class ShoppingCart
  
        {
            public int Id { get; set; }
            public int ItemId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string MediaUrl { get; set; }
        [AllowHtml]
            public string CutomerId { get; set; }
            public int Count { get; set; }
            public DateTime Created { get; set; }
            
            public virtual Item Item { get; set; }
            public virtual ApplicationUser Customer { get; set; }

        
            
                public object Roles { get; internal set; }
                public object Users { get; internal set; }

        internal class Models
        {
            internal class ApplicationDbContext
            {
            }
        }
    }
        }
    