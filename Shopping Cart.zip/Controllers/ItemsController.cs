﻿using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Shopping_Cart.Models;
using System.Web;
using System.IO;
using System;
using Microsoft.AspNet.Identity;

namespace Shopping_Cart.Controllers
{
    public class ItemsController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Items
        //public ActionResult Index()
        //{
        //    return View(db.Items.ToList());
        //}

        private new ActionResult View(object p)
        {
            throw new NotImplementedException();
        }

        // GET: Items/Details/5
        //public ActionResult Details(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Item item = db.Items.Find(id);
        //    if (item == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(item);
        //}


        // GET: Items/Create
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Address,City,State,Zipcode,Country,Phone")] Order order)
        //{
        //    var user = db.Users.Find(User.Identity.GetUserId());
        //    var shoppingcart = db.ShoppingCarts.Where(s => s.Customer == user).ToList();
        //    decimal totalAmt = 0;

        //    {
        //        if (ModelState.IsValid)
        //        {
        //            foreach (var product in shoppingcart)
        //            {
        //                OrderDetail orderdetail = new OrderDetail();
        //                orderdetail.ItemId = product.ItemId;
        //                orderdetail.OrderId = order.Id;
        //                orderdetail.Quantity = product.Count;
        //                orderdetail.UnitPrice = product.Item.Price;
        //                totalAmt += (product.Count * product.Item.Price);

        //                db.OrderDetails.Add(orderdetail);
        //            }


        //            order.OrderDate = DateTime.Now;
        //            order.CustomerId = user;
        //            db.Orders.Add(order);
        //            db.SaveChanges();
        //            return RedirectToAction("Index");
        //        }
        //    }
        //    ViewBag.NoItem = "There's no item to order";
        //    return View(order);
        //}

        // GET: Items/Edit/5
        //public ActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Item item = db.Items.Find(id);
        //    if (item == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(item);
        //}

        // POST: Items/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,Name,Price,MediaUrl,Description,Created,Updated")] Item item)
        {
            if (ModelState.IsValid)
            {
                db.Entry(item).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(item);
        }

        // GET: Items/Delete/5
        //public ActionResult Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Item item = db.Items.Find(id);
        //    if (item == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(item);
        //}

        // POST: Items/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public ActionResult DeleteConfirmed(int id)
        //{
        //    Item item = db.Items.Find(id);
        //    db.Items.Remove(item);
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


    }
}
