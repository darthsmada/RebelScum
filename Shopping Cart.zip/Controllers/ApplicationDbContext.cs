﻿namespace ShoppingApp.Controllers
{
    public class ApplicationDbContext
    {
    }
}