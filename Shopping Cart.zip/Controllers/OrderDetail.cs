﻿namespace Shopping_Cart.Controllers
{
    internal class OrderDetail
    {
        public object ItemId { get; internal set; }
        public object OrderId { get; internal set; }
        public int Quantity { get; internal set; }
        public object UnitPrice { get; internal set; }
    }
}