﻿using Shopping_Cart.Models;

namespace Shopping_Cart.Controllers
{
    internal class ShoppingCart
    {
        internal object ItemID;





        internal class ApplicationDbContext
        {
        }
    }
}
