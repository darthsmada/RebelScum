﻿using System;

namespace Shopping_Cart.Controllers
{
    public class Item
    {

    }
}